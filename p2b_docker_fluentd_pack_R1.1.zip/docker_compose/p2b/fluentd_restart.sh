#!/bin/bash

# !!! The directories and docker services shall be modified by projects !!!

# stop fluentd
# !!! change directory for execution of docker-compose.yml !!!
/usr/local/bin/docker-compose -f /<your work directory>/docker_compose/p2b/docker-compose.yml stop fluentd_p2b_sub
/usr/local/bin/docker-compose -f /<your work directory>/docker_compose/p2b/docker-compose.yml stop fluentd_p2b
# Sample
#/usr/local/bin/docker-compose -f /home/toyosiat/docker_prod/docker_compose/p2b/docker-compose.yml stop fluentd_p2b_sub
#/usr/local/bin/docker-compose -f /home/toyosiat/docker_prod/docker_compose/p2b/docker-compose.yml stop fluentd_p2b

# delete over 1440 rows in pos file
cd /data/dx_plant/p2b/sending

tail -n 1440 dcs_pos.pos > temp.pos
mv temp.pos dcs_pos.pos
tail -n 1440 dcs_pos_sub.pos > temp_sub.pos
mv temp_sub.pos dcs_pos_sub.pos

# Change pos file's owner to uid=1000
# because this shell script is executed by 'root' and the replaced files' owner becames 'root'.
chown -R 1000:1000 /data/dx_plant/p2b/sending

# delete csv files
cd /data/dx_plant/p2b/send/dcs

find /data/dx_plant/p2b/send/dcs -name 'P2B_DCS_*.csv' -mtime +0 -delete

# restart fluentd
# !!! change directory for execution of docker-compose.yml !!!
/usr/local/bin/docker-compose -f /<your work directory>/docker_compose/p2b/docker-compose.yml start fluentd_p2b
/usr/local/bin/docker-compose -f /<your work directory>/docker_compose/p2b/docker-compose.yml start fluentd_p2b_sub
# Sample
#/usr/local/bin/docker-compose -f /home/toyosiat/docker_prod/docker_compose/p2b/docker-compose.yml start fluentd_p2b
#/usr/local/bin/docker-compose -f /home/toyosiat/docker_prod/docker_compose/p2b/docker-compose.yml start fluentd_p2b_sub

exit 0
